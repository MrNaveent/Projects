//#####
import React, {useEffect, useState} from 'react';
import {getEmployees} from "../../logic/api";
import EmployeeListItem from "./EmployeeListItem";
import {Employee} from "../../model/Employee";
import Loader from "../utils/Loader";
import AddEmployeeFormContainer from './addEmployeeForm/AddEmployeeFormContainer';

const EmployeeList: React.FC = () => {
    const [employees, setEmployees] = useState([] as Employee[]);
    const [loading, setLoading] = useState(true);

    const updateList = () => {
        getEmployees()
            .then(e => setEmployees(e))
            .catch(e => console.error(`Failed to fetch: ${JSON.stringify(e)}`))
            .finally(() => setLoading(false))
    }

    useEffect(() => {
        updateList()
    }, [])

    return (
        <Loader loading={loading}>
            <h1>Employee list</h1>
            {employees.map(e => <EmployeeListItem key={e.id} employee={e} updateList={updateList} />)}
            <AddEmployeeFormContainer updateList={updateList} />
        </Loader>
    );
}
export default EmployeeList;
