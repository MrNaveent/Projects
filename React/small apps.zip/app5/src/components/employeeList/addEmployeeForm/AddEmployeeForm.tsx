//######
import React, {createRef} from 'react';
import {generateKey} from "../../../utils/generateKey";
import {Employee} from "../../../model/Employee";

export interface AddEmployeeFormProps {
    saveEmployee: (employee: Employee) => void;
    hideForm: () => void;
}

const AddEmployeeForm: React.FC<AddEmployeeFormProps> = (props: AddEmployeeFormProps) => {
    const nameInputRef = createRef<HTMLInputElement>();
    return (
        <form onSubmit={(e) => e.preventDefault()}>
            <h2>Add new employee</h2>
            <button onClick={props.hideForm}>Cancel</button>
            <input ref={nameInputRef} type="text" placeholder="Employee Name"/>
            <br/>
            <button type="submit" disabled={(nameInputRef.current?.value.length ?? 0) > 0}
                    onClick={() => props.saveEmployee({ id: generateKey(), name: nameInputRef.current?.value ?? "", isActive: true })}>
                Save
            </button>
        </form>
    )
}

export default AddEmployeeForm;
