//######
import React, {useState} from 'react';
import AddEmployeeForm from "./AddEmployeeForm";
import {Employee} from "../../../model/Employee";
import {addEmployee} from "../../../logic/api";
import Loader from "../../utils/Loader";

export interface AddEmployeeProps {
    updateList: () => void;
}

const AddEmployeeFormContainer: React.FC<AddEmployeeProps> = (props: AddEmployeeProps) => {
    const [issave, setIssave] = useState(false);
    const [formShow, setformShow] = useState(false);
    return (
        <Loader loading={issave} label={"save"}>
            { formShow ?
                <AddEmployeeForm saveEmployee={(employee) => {
                    setIssave(true)
                    return addEmployee(employee)
                        .then(() => props.updateList())
                        .catch((e) => console.error("Failed to save: " + JSON.stringify(e)))
                        .finally(() => setIssave(false))
                }} hideForm={() => setformShow(false)}/>
                :
                <button onClick={() => setformShow(true)}>Add employee</button>
            }
        </Loader>
    )
}

export default AddEmployeeFormContainer;
