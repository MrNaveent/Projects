import React, {useState} from 'react';
import {Employee} from "../../model/Employee";
import {deleteEmployee} from "../../logic/api";
import Loader from "../utils/Loader";

export interface EmployeeListItemProps {
    employee: Employee;
    updateList: () => void;
}

const EmployeeListItem: React.FC<EmployeeListItemProps> = (props: EmployeeListItemProps) => {
    const [isBeingDeleted, setIsBeingDeleted] = useState(false);
    return (
        <Loader loading={isBeingDeleted} label={"Deleted"}>
            <span style={{display: "none"}}>{props.employee.id}.</span>
            <h4>{props.employee.name}</h4>
            <button onClick={() => {
                setIsBeingDeleted(true);
                deleteEmployee(props.employee.id)
                    .catch(e => {
                        console.error(`Failed to delete: ${JSON.stringify(e)}`)
                        setIsBeingDeleted(false);
                    })
                    .finally(props.updateList)
            }}>Delete</button>
        </Loader>
    );
}

export default EmployeeListItem;
