//#######
import React from 'react';
import EmployeeList from "./employeeList/EmployeeList";

const App = () => (
    <EmployeeList/>
)

export default App;