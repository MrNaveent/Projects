import React from 'react';

interface LoaderInnerProps {
    loading: boolean;
    label?: string;
}

export declare type LoaderProps = React.PropsWithChildren<LoaderInnerProps>;

const Loader: React.FC<LoaderProps> = (props: LoaderProps) => {

    if (props.loading) {
        return (
            <>
                {(props.label ?? "Loading") + "..."}
            </>
        )
    } else {
        return (
            <>
                {props.children}
            </>
        )
    }
}

export default Loader;
