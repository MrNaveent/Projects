const alphaNum = '0123456789abcdefghijklmnopqrstuvwxyz';

export const generateKey = () => {
    let result = '';
    for (let i = 0; i < 24; i++)
        result += alphaNum[Math.floor(Math.random() * alphaNum.length)];
    return result;
};