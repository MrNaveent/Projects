import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { NavigationContainer } from "@react-navigation/native";
import { useEffect, useState } from "react";
import {
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  SafeAreaView,
  StyleSheet,
  Text,
  View,
  FlatList,
  Image,
} from "react-native";
let timestamp = 0;

function cntreslist({ navigation }) {
  const [isload, setload] = useState(false);
  const [countries, setCountries] = useState([]);
  const [search, setSearch] = useState("");

  const getCountries = async () => {
    setload(true);
    var url;
    const date = new Date().getTime();
    if (search.length >= 3) {
      url = "https://restcountries.com/v3.1/name/" + search;
    } else {
      url = "https://restcountries.com/v3.1/all";
    }
    const response = await fetch(url).then((response) =>
      response.ok ? response.json() : []
    );
    if (timestamp < date) {
      timestamp = date;
      setCountries(response);
    }
    setload(false);
  };

  useEffect(() => {
    navigation.setOptions({
      headerSearchBarOptions: {
        onChangeText: (search) => setSearch(search.nativeEvent.text),
      },
    });
    getCountries();
  }, [search]);

  const navigateToCountryDetails = (country) => {
    navigation.navigate("cntresdtl", country);
  };

  const renderCountry = ({ item }) => {
    return (
      <TouchableOpacity onPress={() => navigateToCountryDetails(item)}>
        <Text>{item.name.common}</Text>
      </TouchableOpacity>
    );
  };
  return (
    <SafeAreaView style={styles.container}>
      {isload ? (
        <ActivityIndicator />
      ) : (
        <>
          <FlatList
            data={countries}
            ListHeaderComponent={<Text>Found: {countries.length}</Text>}
            renderItem={renderCountry}
            keyExtractor={(item) => item.name.common}
            refreshControl={
              <RefreshControl refreshing={isload} onRefresh={getCountries} />
            }
          />
        </>
      )}
    </SafeAreaView>
  );
}

function cntresdtl({ route }) {
  const country = route.params;
  const flag =
    "https://flagcdn.com/48x36/" + country.cca2.toLowerCase() + ".png";
  return (
    <View style={styles.countryDetails}>
      <Image source={{ uri: flag }} style={{ width: 90, height: 70 }} />
      <Text>Official Name: {country.name.official}</Text>
      <Text>Common Name: {country.name.common}</Text>
      <Text>Capital City: {country.capital}</Text>
      <Text>Region: {country.region}</Text>
      <Text>Area: {country.area}</Text>
      <Text>Population: {country.population}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "lightblue",
  },
  countryDetails: {
    backgroundColor: "lightblue",
    alignItems: "center",
    justifyContent: "center",
  },
});

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen
          name="cntreslist"
          component={cntreslist}
          options={{ title: "Countries List" }}
        />
        <Stack.Screen
          name="cntresdtl"
          component={cntresdtl}
          options={{ title: "Country Details" }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
