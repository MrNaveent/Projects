import React, { useEffect, useState } from "react";
function Player(props){
    
    return (
        <div className="player">
        <h1 style={{ color: 'red' }}>Player Information</h1>

        <div>
            <label>Name: {props.name}</label><br/>
            <label>Played: {props.played}</label><br/>
            <button
                 onClick={props.click}>
                {props.turn? "This Gamer is playing now" : "Let's Play"}
            </button>
        </div>
        </div>
    );
    
}
export default Player;