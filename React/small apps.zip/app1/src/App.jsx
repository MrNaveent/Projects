import React from 'react';
import './App.css';
import Player from './components/com1';
import GameAdmin from './components/com2';
import { useEffect, useState } from "react";

function App() {

  

  
  
{}
  return (
    <div className="App">
      <GameAdmin/>
    </div>
    
  );
}

export default App;
