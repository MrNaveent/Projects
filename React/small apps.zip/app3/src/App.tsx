import React from 'react';
import Summ from './Components/CustomerForm';

const App: React.FC = () => {
    return (
        <Summ/>
    );
}

export default App;