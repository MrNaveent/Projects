import React, { useState } from "react";
import { Form, Card, Button } from "react-bootstrap";
import validator from "validator";



const Final= ({ nextStep, handleFormData, values, prevStep }:any) => {

  const { firstName, lastName, email, delivarystreet, delivarycity, delivaryzipcode, invoicestreet, invoicecity, invoicezipcode } = values;
  const submitFormData = (e:any) => 
    e.preventDefault()
  
  return (
    <>
    
      <Card style={{ marginTop: 100, textAlign: "center" }}>
        <Card.Body>
          <h2 className="m-5">SUMMARY</h2>
          <p>
            <strong>First Name :</strong> {firstName}{" "}
          </p>
          <p>
            <strong>Last Name :</strong> {lastName}{" "}
          </p>
          <p>
            <strong>Email :</strong> {email}{" "}
          </p>
          <p>
            <strong>Delivary Street :</strong> {delivarystreet}{" "}
          </p>
          <p>
            <strong>Delivary City :</strong> {delivarycity}{" "}
          </p>
          <p>
            <strong>Delivary Zip Code :</strong> {delivaryzipcode}{" "}
          </p>
           
          <p>
            <strong>Invoice Street :</strong> {invoicestreet}{" "}
          </p>
          <p>
            <strong>Invoice City :</strong> {invoicecity}{" "}
          </p>
          <p>
            <strong>Invoice Zip Code :</strong> {invoicezipcode}{" "}
          </p>
          <Form onSubmit={submitFormData}>
          <div style={{ display: "flex", justifyContent: "space-around" }}>
              <Button variant="primary" onClick={prevStep}>
                Address Part
              </Button>

              <Button variant="primary" onClick={nextStep}>
                Name Part
              </Button>
          
            </div>
            </Form>

        </Card.Body>
      </Card>
    </>
  );
};


export default Final;
