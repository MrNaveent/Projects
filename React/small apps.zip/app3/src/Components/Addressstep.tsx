import React, { useState } from "react";
import { Form, Card, Button } from "react-bootstrap";
import validator from "validator";

const StepTwo = ({
  nextStep,
  handleFormData,
  prevStep,
  values,
  copyadd,
}: any) => {
  const [error, setError] = useState(false);

  const submitFormData = (e: any) => {
    e.preventDefault();

    if (
      validator.isEmpty(values.delivarystreet) ||
      validator.isEmpty(values.delivarycity) ||
      validator.isEmpty(values.delivaryzipcode) ||
      validator.isEmpty(values.invoicestreet) ||
      validator.isEmpty(values.invoicecity) ||
      validator.isEmpty(values.invoicezipcode)
    ) {
      setError(true);
    } else {
      nextStep();
    
    }
   
  };
  return (
    <>
      <Card style={{ marginTop: 100, textAlign: "center" }}>
        <Card.Body>
          <Form onSubmit={submitFormData}>
            <h4 className="m-5">Delivary Address</h4>
            <Form.Group className="mb-3">
              <Form.Label>Delivary Street</Form.Label>
              <Form.Control
                style={{ border: error ? "2px solid red" : "" }}
                type="number"
                min="1"
                defaultValue={values.delivarystreet}
                placeholder="Delivary Street"
                onChange={handleFormData("delivarystreet")}
              />
              {error ? (
                <Form.Text style={{ color: "red" }}>
                  This field is mandatory
                </Form.Text>
              ) : (
                ""
              )}
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Delivary City</Form.Label>
              <Form.Control
                style={{ border: error ? "2px solid red" : "" }}
                name="delivarycity"
                defaultValue={values.delivarycity}
                type="text"
                pattern="[A-Za-z]+"
                placeholder="Delivary City"
                onChange={handleFormData("delivarycity")}
              />
              {error ? (
                <Form.Text style={{ color: "red" }}>
                  This field is mandatory
                </Form.Text>
              ) : (
                ""
              )}
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label> Delivary Zip Code</Form.Label>
              <Form.Control
                style={{ border: error ? "2px solid red" : "" }}
                name="delivaryzipcode"
                defaultValue={values.delivaryzipcode}
                type="number"
                min="5"
                placeholder="DD-DDD"
                onChange={handleFormData("delivaryzipcode")}
              />

              {error ? (
                <Form.Text style={{ color: "red" }}>
                  This field is mandatory
                </Form.Text>
              ) : (
                ""
              )}
            </Form.Group>

            <h4 className="m-5">Invoice Address</h4>
            <Form onSubmit={submitFormData}>
              <div style={{ display: "flex", justifyContent: "space-around" }}>
                <Button variant="primary" onClick={copyadd}>
                  Same as Delivary Address
                </Button>
              </div>
              <br></br>
            </Form>
            <Form.Group className="mb-3">
              <Form.Label> Invoice Street</Form.Label>
              <Form.Control
                style={{ border: error ? "2px solid red" : "" }}
                type="number"
                min="1"
                defaultValue={values.invoicestreet}
                placeholder="Invoice Street"
                onChange={handleFormData("invoicestreet")}
              />
              {error ? (
                <Form.Text style={{ color: "red" }}>
                  This field is mandatory
                </Form.Text>
              ) : (
                ""
              )}
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Invoice City</Form.Label>
              <Form.Control
                style={{ border: error ? "2px solid red" : "" }}
                type="text"
                pattern="[A-Za-z]+"
                placeholder="Invoice City"
                defaultValue={values.invoicecity}
                onChange={handleFormData("invoicecity")}
              />
              {error ? (
                <Form.Text style={{ color: "red" }}>
                  This field is mandatory
                </Form.Text>
              ) : (
                ""
              )}
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label> Invoice Zip Code</Form.Label>
              <Form.Control
                style={{ border: error ? "2px solid red" : "" }}
                name="invoicezipcode"
                defaultValue={values.invoicezipcode}
                type="number"
                min="5"
                placeholder="DD-DDD"
                onChange={handleFormData("invoicezipcode")}
              />

              {error ? (
                <Form.Text style={{ color: "red" }}>
                  This field is mandatory
                </Form.Text>
              ) : (
                ""
              )}
            </Form.Group>
            <div style={{ display: "flex", justifyContent: "space-around" }}>
              <Button variant="primary" onClick={prevStep}>
                Previous
              </Button>

              <Button variant="primary" type="submit">
                Submit
              </Button>
              
            </div>
          </Form>
          
          
        </Card.Body>
      </Card>
    </>
  );
};

export default StepTwo;
