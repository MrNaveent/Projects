import "../App.css";
import { Container, Row, Col } from "react-bootstrap";
import { useState } from "react";
import Namestep from "./Namestep";
import Addressstep from "./Addressstep";
import Summary from "./Summary";

function Summ() {
 
  const [step, setstep] = useState(1);

  
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    delivarystreet: "",
    delivarycity: "",
    delivaryzipcode: "",
    invoicestreet: "",
    invoicecity: "",
    invoicezipcode: ""
  })

 
  const nextStep = () => {
    setstep(step + 1);
  };

  
  const prevStep = () => {
    setstep(step - 1);
  };

  const handleInputData = (input:any) => (e:any) => {
  
    const {value } = e.target;

   
    setFormData(prevState => ({
      ...prevState,
      [input]: value
  }));
  }


  switch (step) {
   
    case 1:
      return (
        <div className="Summ">
          <Container>
            <Row>
              <Col  md={{ span: 6, offset: 3 }} className="custom-margin">
                <Namestep nextStep={nextStep} handleFormData={handleInputData} values={formData} />
              </Col>
            </Row>
          </Container>
        </div>
      );
    
    case 2:
      return (
        <div className="Summ">
          <Container>
            <Row>
              <Col  md={{ span: 6, offset: 3 }} className="custom-margin">
                <Addressstep nextStep={nextStep} prevStep={prevStep} handleFormData={handleInputData} values={formData} />
              </Col>
            </Row>
          </Container>
        </div>
      );
      
    case 3:
      return (
        <div className="Summ">
          <Container>
            <Row>
              <Col  md={{ span: 6, offset: 3 }} className="custom-margin">
                <Summary nextStep={nextStep} prevStep={prevStep} handleFormData={handleInputData} values={formData}  />
              </Col>
            </Row>
          </Container>
        </div>
      );
      case 4:
        return (
          <div className="Summ">
            <Container>
              <Row>
                <Col  md={{ span: 6, offset: 3 }} className="custom-margin">
                  <Namestep nextStep={nextStep} prevStep={prevStep} handleFormData={handleInputData} values={formData}  />
                </Col>
              </Row>
            </Container>
          </div>
        );
        case 5:
          return (
            <div className="Summ">
              <Container>
                <Row>
                  <Col  md={{ span: 6, offset: 3 }} className="custom-margin">
                    <Addressstep nextStep={nextStep} prevStep={prevStep} handleFormData={handleInputData} values={formData} />
                  </Col>
                </Row>
              </Container>
            </div>
          );
          case 6:
            return (
              <div className="Summ">
                <Container>
                  <Row>
                    <Col  md={{ span: 6, offset: 3 }} className="custom-margin">
                      <Summary nextStep={nextStep} prevStep={prevStep} handleFormData={handleInputData} values={formData}  />
                    </Col>
                  </Row>
                </Container>
              </div>
            ); 
            case 7:
              return (
                <div className="Summ">
                  <Container>
                    <Row>
                      <Col  md={{ span: 6, offset: 3 }} className="custom-margin">
                        <Namestep nextStep={nextStep} prevStep={prevStep} handleFormData={handleInputData} values={formData}  />
                      </Col>
                    </Row>
                  </Container>
                </div>
              );               
    default:
      return (
        <div className="Summ">
        </div>
      );
  }
}

export default Summ;
