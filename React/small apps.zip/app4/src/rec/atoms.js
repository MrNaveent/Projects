import { atom } from "recoil";

import { selector } from "recoil";
import Contcodes from './Contcodes'
import noflag from '../noflag.jpeg'

export const team2flagState = selector({
    key: 'team2flagState',
    get: ({ get }) => {
        const Cc = get(team2CcState);
        const result = Contcodes.find(country => country.code === Cc);
        if (result) {
            return "https://cloudinary.fifa.com/api/v1/picture/flags-sq-2/" + Cc + "?tx=c_fill,g_auto,q_auto,w_70,h_46";
        }else{
            return noflag
        }    
    }
});

export const team1flagState = selector({
    key: 'team1flagState',
    get: ({ get }) => {
        const Cc = get(team1CcState);
        const result = Contcodes.find(country => country.code === Cc);
        if (result) {
            return "https://cloudinary.fifa.com/api/v1/picture/flags-sq-2/" + Cc + "?tx=c_fill,g_auto,q_auto,w_70,h_46";
        }else{
            return noflag;
        }

    }
});

export const team1nameState = selector({
    key: 'team1nameState',
    get: ({ get }) => {
        const Cc = get(team1CcState);
        const result = Contcodes.find(country => country.code === Cc)
        if (result) {
            return result.name;
        }
        else {
            return Cc;
        }
    },
});

export const team2nameState = selector({
    key: 'team2nameState',
    get: ({ get }) => {
        const Cc = get(team2CcState);
        const result = Contcodes.find(country => country.code === Cc)
        if (result) {
            return result.name;
        }
        else {
            return Cc;
        }
    },
});

export const StadiumState = atom({
    key: 'StadiumState',
    default: '',
});

export const team1scoreState = atom({
    key: 'team1scoreState',
    default: 0,
});

export const team2scoreState = atom({
    key: 'team2scoreState',
    default: 0,
});

export const team1CcState = atom({
    key: 'team1CcState',
    default: '',
});

export const team2CcState = atom({
    key: 'team2CcState',
    default: '',
});