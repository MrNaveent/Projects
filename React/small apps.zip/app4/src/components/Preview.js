import { team1nameState, 
         team2nameState, 
         team2flagState, 
         team1flagState,
         team1CcState, 
         team2CcState, 
         StadiumState, 
         team1scoreState, 
         team2scoreState } from '../rec/atoms'

import { useRecoilState, 
         useRecoilValue } from 'recoil';


function Preview() {   
  const team2flag = useRecoilValue(team2flagState);
  const team1flag = useRecoilValue(team1flagState);
  const team2 = useRecoilValue(team2nameState);
  const team1 = useRecoilValue(team1nameState);

  const [team1Cc, setteam1Cc] = useRecoilState(team1CcState);
  const [team2Cc, setteam2Cc] = useRecoilState(team2CcState);
  const [stadium, setStadium] = useRecoilState(StadiumState);
  const [team1score, setteam1score] = useRecoilState(team1scoreState);
  const [team2score, setteam2score] = useRecoilState(team2scoreState);
  
  return (
    <div className="Preview">
      <h2>PREVIEW</h2>
      <div id='flags_teams'>
        <div id='first'>
          <img src={team1flag} alt="Team1_flag"></img>
          <br></br>
          <span>{team1}</span>
        </div>
        <div id='second'>
          <img src={team2flag} alt="Team2_flag"></img>
          <br></br>
          <span>{team2}</span>
          

        </div>
      </div>
      <div id='stadium_scores'>
      <br></br>
        <label>Stadium: {stadium}</label>
        <br></br>
        <h3>Score</h3>
        <span>{team1score} : {team2score}</span>
      </div>
    </div>
  );
}

export default Preview;