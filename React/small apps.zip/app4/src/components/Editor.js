import { team1nameState, 
         team2nameState,
         team1CcState, 
         team2CcState, 
         StadiumState, 
         team1scoreState, 
         team2scoreState  } from '../rec/atoms'

import { useRecoilState, 
        useRecoilValue } from 'recoil';
function Editor() {
    const [team1score, setteam1score] = useRecoilState(team1scoreState);
    const [team2score, setteam2score] = useRecoilState(team2scoreState);

    const [team1Cc, setteam1Cc] = useRecoilState(team1CcState);
    const [team2Cc, setteam2Cc] = useRecoilState(team2CcState);
    const [stadium, setStadium] = useRecoilState(StadiumState);

    const team2 = useRecoilValue(team2nameState);
    const team1 = useRecoilValue(team1nameState);
    
    const incrementteam1 = () => {
        setteam1score(team1score + 1);
    }

    const incrementteam2 = () => {
        setteam2score(team2score + 1);
    }

    

    return (
        <div className="Editor">
            <h2>EDITOR</h2>
            <div id='country_codes'>
                <span>Country codes</span>
                <div>
                    <label for='team1_code'>Team1: </label>
                    <input id='team1_code' onChange={(e) => setteam1Cc(e.target.value)}></input>
                </div>
                <div>
                    <label for='team2_code'>Team2: </label>
                    <input id='team2_code' onChange={(e) => setteam2Cc(e.target.value)}></input>
                </div>
            </div>
            <div id='stadium_div'>
                <label for='stadium'>Stadium:</label>
                <input id='stadium' onChange={(e) => setStadium(e.target.value)}></input>
            </div>
            <div id='scores_div'>
                <span>Goals:</span>
                <div>
                    <button id='team1_goal' onClick={incrementteam1}> Score Goal for {team1}</button>
                    <button id='team2_goal' onClick={incrementteam2}> Score Goal for {team2}</button>
                </div>
            </div>
        </div>
            
    );
}

export default Editor;