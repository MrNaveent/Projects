import React from 'react';
import CarsListComponent from './components/CarsListComponent';

const App: React.FC = () => {
    return (
        <CarsListComponent/>
    );
}

export default App;